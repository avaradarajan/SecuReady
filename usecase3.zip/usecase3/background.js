var lstorage = window.localStorage

/* store top 10k sites in db, should be one time operation only */
chrome.runtime.onInstalled.addListener(function(details){

    console.log("first install")

    Papa.parse("top-1m.csv", {
      download:true,
      complete: function(results) {
        for(k = 1; k < 10001; k++) {
          lstorage.setItem(results.data[k][1], "1")
        }
      console.log("finished loading")
      console.log(lstorage.getItem("youtube.com"))
      }
    })
});

chrome.runtime.onMessage.addListener(function(request,sender,sendResponse){
  if(request.todo=="searchDB"){
    console.log("in if bk")
    console.log(request.val)
    if(lstorage.getItem(request.val) == null) {
      sendResponse({return:"null"})
    }

    else{
      sendResponse({return:"proceed"})
    }
  }

  if(request.todo=="remember"){
    lstorage.setItem(request.val, "1")
  }
});
